package com.platform.menu.exception;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuPlatformRuntimeException extends RuntimeException {
    private String errMsgKey;
    private String errorCode;

    public MenuPlatformRuntimeException(Throwable cause) {
        super(cause);
    }

    public MenuPlatformRuntimeException(String errorMessage, Throwable cause) {
        super(errorMessage, cause);
    }

    public MenuPlatformRuntimeException(String errorMessage) {
        super(errorMessage);
    }

    public MenuPlatformRuntimeException(ErrorCode errorCode) {
        super(errorCode.getErrMsgKey());
        this.errMsgKey = errorCode.getErrMsgKey();
        this.errorCode = errorCode.getErrCode();

    }

}
