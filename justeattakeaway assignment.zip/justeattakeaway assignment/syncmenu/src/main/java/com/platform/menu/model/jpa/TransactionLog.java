package com.platform.menu.model.jpa;

import com.platform.menu.model.enums.MenuState;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor

@Table(name = "TransactionLog")
public class TransactionLog {
    @SequenceGenerator(
            name = "transaction_id_seq",
            sequenceName = "transaction_id_seq"
    )
    @GeneratedValue(
            strategy = GenerationType.AUTO,
            generator = "transaction_id_seq"
    )
    @Id

    @Column(name = "id")
    private Integer id;

    @Column(name = "TransactionDate")
    private Timestamp transactionDate;
    @Column(name = "MenuId")
    private Integer menuId;
    @Column(name = "MenuCount")
    private Integer menuCount;
    @Column(name = "Message")
    private String message;
    @Column(name = "MenuState")
    @Enumerated(EnumType.STRING)
    private MenuState MenuState;

}
