package com.platform.menu.model.contract;

import com.platform.menu.model.enums.CompanyState;
import com.platform.menu.model.jpa.Menu;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class CompanyRequest {
    private Integer id;

    private String companyName;


    private CompanyState state;


 }
