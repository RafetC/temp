package com.platform.menu.model.enums;

public enum MenuSize {
    Small,
    Medium,
    Large
}
