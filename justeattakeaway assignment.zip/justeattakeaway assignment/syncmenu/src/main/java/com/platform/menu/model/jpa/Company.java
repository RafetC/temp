package com.platform.menu.model.jpa;


import com.platform.menu.model.enums.CompanyState;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Company")
public class Company {
    @SequenceGenerator(
            name = "company_id_seq",
            sequenceName = "company_id_seq"
    )
    @GeneratedValue(
            strategy = GenerationType.AUTO,
            generator = "company_id_seq"
    )
    @Id

    @Column(name = "Company_Id")
    private Integer id;
    @Column(name = "CompanyName")
    private String companyName;

    @Column(name = "CompanyState")
    @Enumerated(EnumType.STRING)
    private CompanyState state;
    @Column(name = "CreateDate")
    private Timestamp createDate;

    @ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
            name = "Company_Menu",
            joinColumns = { @JoinColumn(name = "Company_Id") },
            inverseJoinColumns = { @JoinColumn(name = "Menu_Id") }

    )
    private Set<Menu> menus = new   HashSet<>();

}
