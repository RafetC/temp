package com.platform.menu.model.contract;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.platform.menu.model.enums.CompanyState;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class CompanyResponse {
    private Integer id;

    private String companyName;
  //  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd‐MM‐yyyy HH:mm")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Timestamp createDate;
    private CompanyState state;
}
