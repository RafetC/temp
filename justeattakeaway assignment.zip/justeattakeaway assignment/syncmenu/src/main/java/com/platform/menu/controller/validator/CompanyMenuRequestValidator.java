package com.platform.menu.controller.validator;

import com.platform.menu.controller.validator.annotation.CheckCompanyMenu;
import com.platform.menu.exception.ErrorCode;
import com.platform.menu.exception.MenuPlatformRuntimeException;
import com.platform.menu.model.contract.CompanyMenuRequest;
import com.platform.menu.model.enums.CompanyState;
import com.platform.menu.model.enums.MenuSize;
import com.platform.menu.model.enums.MenuState;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.stream.Collectors;

public class CompanyMenuRequestValidator implements ConstraintValidator<CheckCompanyMenu, CompanyMenuRequest> {


    @Override
    public void initialize(CheckCompanyMenu constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(CompanyMenuRequest companyMenuRequest, ConstraintValidatorContext constraintValidatorContext) {

        checkCompanyName(companyMenuRequest);
        checkCategoryName(companyMenuRequest);
        checkProductName(companyMenuRequest);

        return true;
    }

    public void checkCompanyName(CompanyMenuRequest companyMenuRequest) {
        if (companyMenuRequest.getCompanyDto().getCompanyName().isBlank()) {
            throw new MenuPlatformRuntimeException(ErrorCode.INVALID_Company_Name);
        }
    }

    public void checkCategoryName(CompanyMenuRequest companyMenuRequest) {
        if (companyMenuRequest.getMenuDto().stream().filter(p -> p.getCategoryName().isBlank()).collect(Collectors.toList()).size() > 0) {
            throw new MenuPlatformRuntimeException(ErrorCode.INVALID_Category_Name);
        }
    }

    public void checkProductName(CompanyMenuRequest companyMenuRequest) {
        if (companyMenuRequest.getMenuDto().stream().filter(p -> p.getProductName().isBlank()).collect(Collectors.toList()).size() > 0) {
            throw new MenuPlatformRuntimeException(ErrorCode.INVALID_Product_Name);
        }
    }






}