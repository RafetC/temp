package com.platform.menu.dto;

import com.platform.menu.model.enums.CompanyState;
import com.platform.menu.model.jpa.Menu;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CompanyDto {


    private Integer id;

    private String companyName;


    private CompanyState state;

    private Timestamp createDate;

 }
