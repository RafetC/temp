package com.platform.menu.repository;


import com.platform.menu.model.jpa.TransactionLog;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;


@Repository
public interface TransactionLogRepository extends JpaRepository<TransactionLog, Integer> {


}
