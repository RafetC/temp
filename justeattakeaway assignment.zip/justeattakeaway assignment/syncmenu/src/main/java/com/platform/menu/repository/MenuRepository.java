package com.platform.menu.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.transaction.annotation.Transactional;
import com.platform.menu.model.jpa.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MenuRepository extends JpaRepository<Menu, Integer> {

    Menu getMenuById(Integer id);
    @Transactional
    @Modifying
    @Query("UPDATE Menu m SET m.count = m.count-1 WHERE m.id = :menuId and m.count>0 and m.isActive='Active' ")
    int offerMenu(@Param("menuId") int menuId);
}
