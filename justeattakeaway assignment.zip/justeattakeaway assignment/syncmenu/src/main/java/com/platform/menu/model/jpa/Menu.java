package com.platform.menu.model.jpa;

import com.platform.menu.model.enums.MenuSize;
import com.platform.menu.model.enums.MenuState;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor

@Table(name = "Menu")
public class Menu {
    @SequenceGenerator(
            name = "menu_id_seq",
            sequenceName = "menu_id_seq"
    )
    @GeneratedValue(
            strategy = GenerationType.AUTO,
            generator = "menu_id_seq"
    )
    @Id

    @Column(name = "Menu_Id")
    private Integer id;
    @ManyToMany(mappedBy = "menus")
    private Set<Company> companies = new HashSet<>();
    @Column(name = "CategoryName")
    private String categoryName;
    @Column(name = "ProductName")
    private String productName;
    @Column(name = "Size")
    @Enumerated(EnumType.STRING)
    private MenuSize size;
    @Column(name = "Count")
    private Integer count;
    @Column(name = "IsActive")
    @Enumerated(EnumType.STRING)
    private MenuState isActive;


}
