package com.platform.menu.controller.validator.annotation;

 import com.platform.menu.controller.validator.CompanyMenuRequestValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = CompanyMenuRequestValidator.class)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface CheckCompanyMenu {

    String message() default "Dish Type should be Vegeterian or Vegan or Meat";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
