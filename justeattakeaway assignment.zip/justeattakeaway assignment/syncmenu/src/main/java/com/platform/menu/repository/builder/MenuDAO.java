package com.platform.menu.repository.builder;

import com.platform.menu.model.jpa.Company;
import com.platform.menu.model.jpa.Menu;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class MenuDAO {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Menu> searchMenu(List<SearchCriteria> params) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Menu> query = builder.createQuery(Menu.class);
        Root r = query.from(Menu.class);

        Predicate predicate = builder.conjunction();

        MenuSearchQueryCriteriaConsumer searchConsumer =
                new MenuSearchQueryCriteriaConsumer(predicate, builder, r);
        params.stream().forEach(searchConsumer);
        predicate = searchConsumer.getPredicate();
        query.where(predicate);

        List<Menu> result = entityManager.createQuery(query).getResultList();
        return result;
    }
}
