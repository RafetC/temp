package com.platform.menu.service;

import com.platform.menu.dto.CompanyDto;
import com.platform.menu.dto.CompanyMenuDto;
import com.platform.menu.dto.MenuDto;
import com.platform.menu.model.jpa.Company;
import com.platform.menu.model.jpa.Menu;
import com.platform.menu.model.jpa.TransactionLog;
import com.platform.menu.repository.CompanyRepository;
import com.platform.menu.repository.MenuRepository;
import com.platform.menu.repository.TransactionLogRepository;
import com.platform.menu.repository.builder.CompanyDAO;
import com.platform.menu.repository.builder.MenuDAO;
import com.platform.menu.repository.builder.SearchCriteria;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class MenuServiceImpl implements MenuService {

    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    MenuRepository menuRepository;
    @Autowired
    TransactionLogRepository transactionLogRepository;


    @Autowired
    CompanyDAO companyApi;
    @Autowired
    MenuDAO menuApi;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public CompanyMenuDto syncMenu(CompanyMenuDto companyMenuDto) {
        Company company = new Company();
        if (companyMenuDto.getCompanyDto().getId() == null) // migrate new restaurant
        {
            company = modelMapper.map(companyMenuDto.getCompanyDto(), Company.class);
            company.setCreateDate(getTimeSpampOfNow());
        } else {
            company = companyRepository.getCompanyById(companyMenuDto.getCompanyDto().getId());
            if (company == null) {
                company = modelMapper.map(companyMenuDto.getCompanyDto(), Company.class);
                company.setCreateDate(getTimeSpampOfNow());
            } else {
                company.setCompanyName(companyMenuDto.getCompanyDto().getCompanyName());
                company.setState(companyMenuDto.getCompanyDto().getState());
            }

        }


        Company finalCompany = company;
        companyMenuDto.getMenuDto().stream().forEach(menuDTO -> {
            Menu menuToUpdate = menuRepository.getMenuById(menuDTO.getId());
            List<Menu> menus = new ArrayList<>();
            if (menuToUpdate != null) {
                menuToUpdate.setSize(menuDTO.getSize());
                menuToUpdate.setCategoryName(menuDTO.getCategoryName());
                menuToUpdate.setProductName(menuDTO.getProductName());
                menuToUpdate.setCount(menuDTO.getCount());
                menuToUpdate.setIsActive(menuDTO.getIsActive());
                menus.add(menuToUpdate);
                finalCompany.getMenus().removeIf(p -> p.getId().equals(menuToUpdate.getId()));
            } else {
                Menu menuInsert = modelMapper.map(menuDTO, Menu.class);
                menus.add(menuInsert);
            }
            Set<Menu> menuHashSet = new HashSet<>(menus);
            finalCompany.getMenus().addAll(menuHashSet);

        });

        company = companyRepository.save(company);
        CompanyMenuDto companyMenuDtoResponse = modelMapper.map(company, CompanyMenuDto.class);
        companyMenuDtoResponse.setMenuDto(modelMapper.map(company.getMenus(), new TypeToken<List<Menu>>() {
        }.getType()));
        return companyMenuDtoResponse;
    }


    @Override
    public List<CompanyDto> searchCompany(Optional<Object> Id, Optional<Object> companyName) {
        List<SearchCriteria> searchCriteria = new ArrayList<>();

        searchCriteria.add(new SearchCriteria("companyName", "%", companyName));
        searchCriteria.add(new SearchCriteria("id", ":", Id));

        List<Company> companyList = companyApi.searchCompany(searchCriteria);


        List<CompanyDto> companyDtoList = companyList
                .stream()
                .map(rec -> modelMapper.map(rec, CompanyDto.class))
                .collect(Collectors.toList());


        return companyDtoList;


    }


    @Override
    public List<MenuDto> searchMenu(Optional<Object> Id, Optional<Object> productName, Optional<Object> categoryName) {
        List<SearchCriteria> searchCriteria = new ArrayList<>();

        searchCriteria.add(new SearchCriteria("categoryName", "%", categoryName));
        searchCriteria.add(new SearchCriteria("productName", "%", productName));
        searchCriteria.add(new SearchCriteria("id", ":", Id));

        List<Menu> menuList = menuApi.searchMenu(searchCriteria);


        List<MenuDto> menuDtoList = menuList
                .stream()
                .map(rec -> modelMapper.map(rec, MenuDto.class))
                .collect(Collectors.toList());


        return menuDtoList;


    }


    @Override
    public List<CompanyMenuDto> searchCompanyWithMenu(Optional<Object> companyId, Optional<Object> companyName) {
        List<SearchCriteria> searchCriteria = new ArrayList<>();

        searchCriteria.add(new SearchCriteria("companyName", "%", companyName));
        searchCriteria.add(new SearchCriteria("id", ":", companyId));

        List<Company> companyList = companyApi.searchCompany(searchCriteria);

        List<CompanyMenuDto> companyMenuDtos = companyList
                .stream()
                .map(rec -> modelMapper.map(rec, CompanyMenuDto.class))

                .collect(Collectors.toList());

        IntStream.range(0, companyList.size())
                .forEach(i -> companyMenuDtos.get(i).setMenuDto(companyList.get(i).getMenus().stream().map(src -> modelMapper.map(src, MenuDto.class)).collect(Collectors.toList())));


        return companyMenuDtos;


    }

    @Override
    public int offerMenu(Integer menuId) {
        TransactionLog transactionLog = new TransactionLog();
        Integer updatedRecordCount = menuRepository.offerMenu(menuId);
        transactionLog.setMenuId(menuId);
        transactionLog.setTransactionDate(getTimeSpampOfNow());
        if (updatedRecordCount == 1) {
            transactionLog.setMessage("Menu is offered successfully");
        } else {
            transactionLog.setMessage("Menu isn't offered check menu status and count");
        }
        Menu menu = menuRepository.getById(menuId);
        transactionLog.setMenuCount(menu.getCount());
        transactionLog.setMenuState(menu.getIsActive());
        transactionLogRepository.save(transactionLog);

        return updatedRecordCount;
    }


    public Timestamp getTimeSpampOfNow() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formatDateTime = now.format(formatter);
        Timestamp timestamp = Timestamp.valueOf(formatDateTime);
        return timestamp;
    }

}

