package com.platform.menu.model.contract;

import com.platform.menu.controller.validator.annotation.CheckCompanyMenu;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CompanyMenuResponse {

    private CompanyResponse companyResponse;
    private List<MenuResponse> menuResponses;
}
