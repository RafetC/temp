package com.platform.menu.model.enums;

public enum MenuState {
    Active,
    Passive
}
