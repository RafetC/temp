package com.platform.menu.model.enums;

public enum CompanyState {
    Active,
    Passive
}
