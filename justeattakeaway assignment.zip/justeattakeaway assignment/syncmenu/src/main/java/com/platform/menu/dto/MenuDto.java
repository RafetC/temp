package com.platform.menu.dto;

import com.platform.menu.model.enums.MenuSize;
import com.platform.menu.model.enums.MenuState;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class MenuDto {

    private Integer id;


    private String categoryName;

    private String productName;

    private MenuSize size;

    private Integer count;


    private MenuState isActive;
}
