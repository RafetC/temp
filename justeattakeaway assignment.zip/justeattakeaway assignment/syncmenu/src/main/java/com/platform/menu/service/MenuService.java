package com.platform.menu.service;

import com.platform.menu.dto.CompanyDto;
import com.platform.menu.dto.CompanyMenuDto;
import com.platform.menu.dto.MenuDto;
import com.platform.menu.model.jpa.Company;

import java.util.List;
import java.util.Optional;

public interface MenuService {

    CompanyMenuDto syncMenu(CompanyMenuDto companyMenuDto);

    List<CompanyDto> searchCompany(Optional<Object> id, Optional<Object> companyName);

    List<MenuDto> searchMenu(Optional<Object> Id, Optional<Object> productName, Optional<Object> categoryName);

    List<CompanyMenuDto> searchCompanyWithMenu(Optional<Object> companyId, Optional<Object> companyName);

    int offerMenu(Integer menuId);

}
