package com.platform.menu.repository.builder;

import com.platform.menu.model.jpa.Company;
 import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class CompanyDAO {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Company> searchCompany(List<SearchCriteria> params) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Company> query = builder.createQuery(Company.class);
        Root r = query.from(Company.class);

        Predicate predicate = builder.conjunction();

        MenuSearchQueryCriteriaConsumer searchConsumer =
                new MenuSearchQueryCriteriaConsumer(predicate, builder, r);
        params.stream().forEach(searchConsumer);
        predicate = searchConsumer.getPredicate();
        query.where(predicate);

        List<Company> result = entityManager.createQuery(query).getResultList();
        return result;
    }


}
