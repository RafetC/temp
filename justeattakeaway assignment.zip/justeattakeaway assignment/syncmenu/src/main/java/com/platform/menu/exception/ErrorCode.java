package com.platform.menu.exception;

import lombok.Getter;

@Getter
public enum ErrorCode {
    INVALID_Company_Name("ERR-001", "Company Name shouldn't be empty!"),
    INVALID_Category_Name("ERR-002", "Menu Name shouldn't be empty!"),
    INVALID_Product_Name("ERR-002", "Product Name shouldn't be empty!"),
    INVALID_State_Name_For_Menu("ERR-003", "State Name should be Active or Passive"),
    INVALID_State_Name_For_Company("ERR-004", "State Name should be Active or Passive"),
    INVALID_Menu_Size("ERR-005", "Size should be Small ,Medium or Large"),
    UNEXPECTED_ERROR("ERR-006", "UNEXPECTED_ERROR"),
    ONE_MORE_REQUESTMAPPING("ERR-007", "There are many requestmapping!");


    private String errCode;
    private String errMsgKey;


    private ErrorCode(final String errCode, final String errMsgKey) {
        this.errCode = errCode;
        this.errMsgKey = errMsgKey;
    }

}
