package com.platform.menu.controller;

import com.platform.menu.dto.CompanyDto;
import com.platform.menu.dto.CompanyMenuDto;
import com.platform.menu.dto.MenuDto;
import com.platform.menu.model.contract.*;
import com.platform.menu.service.MenuService;
import io.swagger.annotations.ApiOperation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController("/menuPlatform")
public class MenuController {

    @Autowired
    public ModelMapper modelMapper;
    @Autowired
    public MenuService menuService;

    @ApiOperation(value = "Sync Menu", nickname = "Sync Menu", notes = "This API accepts PUT methods and can sync Menu . If API execute successfully it returns 200 HTTP Code. It validates Request fields with @CheckCompanyMenu annotation . Company and Menu are saved on H2 in memory database")
    @PutMapping("/syncMenu")
    public ResponseEntity<CompanyMenuResponse> syncMenu(@RequestBody @Valid CompanyMenuRequest request) {
        CompanyMenuDto companyMenuDto = modelMapper.map(request, CompanyMenuDto.class);

        CompanyMenuDto companyMenuDtoResponse = menuService.syncMenu(companyMenuDto);
        CompanyMenuResponse companyMenuResponse = modelMapper.map(companyMenuDtoResponse, CompanyMenuResponse.class);
        ResponseEntity<CompanyMenuResponse> response = new ResponseEntity<>(companyMenuResponse, HttpStatus.OK);
        return response;

    }

    @ApiOperation(value = "Get companies", nickname = "Get companies", notes = "This API accepts GET methods and it retrieve company list with dynamic queries. If it execute successfully api returns 200 HTTP code.")
    @GetMapping("/companies")
    public ResponseEntity<List<CompanyResponse>> getCompanies(@RequestParam Optional<Object> id, @RequestParam Optional<Object> companyName) {
        List<CompanyDto> companyResponseDto = menuService.searchCompany(id, companyName);


        List<CompanyResponse> companyList = companyResponseDto
                .stream()
                .map(rec -> modelMapper.map(rec, CompanyResponse.class))
                .collect(Collectors.toList());


        ResponseEntity<List<CompanyResponse>> response = new ResponseEntity<List<CompanyResponse>>(companyList, HttpStatus.OK);
        return response;
    }


    @ApiOperation(value = "Get Menus", nickname = "Get Menus", notes = "This API accepts GET methods and it retrieve menu list with dynamic queries. If it execute successfully api returns 200 HTTP code.")
    @GetMapping("/menus")
    public ResponseEntity<List<MenuResponse>> getMenus(@RequestParam Optional<Object> id, @RequestParam Optional<Object> productName, @RequestParam Optional<Object> categoryName) {

        List<MenuDto> menuDtos = menuService.searchMenu(id, productName, categoryName);


        List<MenuResponse> menuResponses = menuDtos
                .stream()
                .map(rec -> modelMapper.map(rec, MenuResponse.class))
                .collect(Collectors.toList());


        ResponseEntity<List<MenuResponse>> response = new ResponseEntity<List<MenuResponse>>(menuResponses, HttpStatus.OK);
        return response;
    }


    @ApiOperation(value = "Get Menus", nickname = "Get Menus", notes = "This API accepts GET methods and it retrieve company & menu list with dynamic queries. If it execute successfully api returns 200 HTTP code.")
    @GetMapping("/companydetails")
    public ResponseEntity<List<CompanyMenuResponse>> getCompanyWithMenus(@RequestParam Optional<Object> id, @RequestParam Optional<Object> companyName) {

        List<CompanyMenuDto> companyMenuDtos = menuService.searchCompanyWithMenu(id, companyName);


        List<CompanyMenuResponse> menuResponses = companyMenuDtos
                .stream()
                .map(rec -> modelMapper.map(rec, CompanyMenuResponse.class))
                .collect(Collectors.toList());

        ResponseEntity<List<CompanyMenuResponse>> response = new ResponseEntity<List<CompanyMenuResponse>>(menuResponses, HttpStatus.OK);
        return response;
    }


    @ApiOperation(value = "Offer Menu", nickname = "Offer Menu", notes = "This API accepts PUT methods and can offer Menu . If API execute successfully it returns 200 HTTP Code.    Menu count is updated on H2 in memory database")
    @PutMapping("/offerMenu")
    public ResponseEntity<OfferMenuResponse> offerMenu(@RequestBody OfferMenuRequest offerMenuRequest) {

        Integer updatedMenuCount = menuService.offerMenu(offerMenuRequest.getMenuId());
        OfferMenuResponse offerMenuResponse = new OfferMenuResponse();
        offerMenuResponse.setIsOffered(updatedMenuCount == 1 ? true : false);
        ResponseEntity<OfferMenuResponse> response = new ResponseEntity<>(offerMenuResponse, HttpStatus.OK);

        return response;

    }
}
