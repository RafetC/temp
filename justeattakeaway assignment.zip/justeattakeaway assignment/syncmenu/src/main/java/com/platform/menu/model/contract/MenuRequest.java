package com.platform.menu.model.contract;

import com.platform.menu.model.enums.MenuSize;
import com.platform.menu.model.enums.MenuState;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import java.util.Optional;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class MenuRequest {
    private Integer id;


    private String categoryName;

    private String productName;

    private MenuSize size;

    private Integer count;

    private MenuState isActive;
}
