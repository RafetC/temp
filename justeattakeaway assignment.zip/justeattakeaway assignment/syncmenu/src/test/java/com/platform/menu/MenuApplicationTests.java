package com.platform.menu;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.platform.menu.model.contract.*;
import com.platform.menu.model.enums.CompanyState;
import com.platform.menu.model.enums.MenuSize;
import com.platform.menu.model.enums.MenuState;
import com.platform.menu.model.jpa.Menu;
import com.platform.menu.repository.CompanyRepository;
import com.platform.menu.repository.MenuRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.internal.matchers.apachecommons.ReflectionEquals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;
import java.util.stream.Collectors;

import static org.hamcrest.Matchers.greaterThan;
import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@AutoConfigureMockMvc
public class MenuApplicationTests {

    @Test
    public void contextLoads() {
    }

    ObjectMapper om = new ObjectMapper();
    @Autowired
    MenuRepository menuRepository;
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    MockMvc mockMvc;

    Map<String, CompanyMenuRequest> testData;
    Map<String, CompanyMenuResponse> testDataresponse;

    @Before
    public void setup() {
        menuRepository.deleteAll();
        companyRepository.deleteAll();
        testData = getTestDataRequest();
        testDataresponse = getTestDataResponse();

    }


    public List<MenuRequest> getMenuRequestList() {
        List<MenuRequest> menuRequests = new ArrayList<>();
        MenuRequest menuRequest = new MenuRequest();
        menuRequest.setCount(2);
        menuRequest.setId(0);
        menuRequest.setIsActive(MenuState.Active);
        menuRequest.setSize(MenuSize.Medium);
        menuRequest.setCategoryName("Chicken Menu");
        menuRequest.setProductName("Chicken Burger");
        menuRequests.add(menuRequest);
        MenuRequest menuRequest1 = new MenuRequest();
        menuRequest1.setCount(2);
        menuRequest1.setId(0);
        menuRequest1.setIsActive(MenuState.Active);
        menuRequest1.setSize(MenuSize.Large);
        menuRequest1.setCategoryName("Whooper Menu");
        menuRequest1.setProductName("Whooper Burger");
        menuRequests.add(menuRequest1);
        return menuRequests;

    }

    public List<MenuRequest> getSharedMenuRequestList() {
        List<MenuRequest> menuRequests = new ArrayList<>();
        MenuRequest menuRequest1 = new MenuRequest();
        menuRequest1.setCount(4);
        menuRequest1.setId(2);
        menuRequest1.setIsActive(MenuState.Active);
        menuRequest1.setSize(MenuSize.Large);
        menuRequest1.setCategoryName("Whooper Menu");
        menuRequest1.setProductName("Whooper Burger");
        menuRequests.add(menuRequest1);

        return menuRequests;

    }


    public List<MenuRequest> getExistingCompanyNewMenuRequestList() {
        List<MenuRequest> menuRequests = new ArrayList<>();
        MenuRequest menuRequest1 = new MenuRequest();
        menuRequest1.setCount(4);
        menuRequest1.setId(0);
        menuRequest1.setIsActive(MenuState.Active);
        menuRequest1.setSize(MenuSize.Large);
        menuRequest1.setCategoryName("Whooper2 Menu");
        menuRequest1.setProductName("Whooper2 Burger");
        menuRequests.add(menuRequest1);

        return menuRequests;

    }


    public List<MenuResponse> getMenuResponseList() {
        List<MenuResponse> menuResponses = new ArrayList<>();
        MenuResponse menuResponse = new MenuResponse();
        menuResponse.setCount(2);
        menuResponse.setId(0);
        menuResponse.setIsActive(MenuState.Active);
        menuResponse.setSize(MenuSize.Medium);
        menuResponse.setCategoryName("Chicken Menu");
        menuResponse.setProductName("Chicken Burger");
        menuResponses.add(menuResponse);
        MenuResponse menuResponse1 = new MenuResponse();
        menuResponse1.setCount(4);
        menuResponse1.setId(0);
        menuResponse1.setIsActive(MenuState.Active);
        menuResponse1.setSize(MenuSize.Large);
        menuResponse1.setCategoryName("Whooper Menu");
        menuResponse1.setProductName("Whooper Burger");
        menuResponses.add(menuResponse1);
        return menuResponses;

    }


    public List<MenuResponse> getSharedMenuResponseList() {
        List<MenuResponse> menuResponses = new ArrayList<>();
        MenuResponse menuResponse1 = new MenuResponse();
        menuResponse1.setCount(4);
        menuResponse1.setId(2);
        menuResponse1.setIsActive(MenuState.Active);
        menuResponse1.setSize(MenuSize.Large);
        menuResponse1.setCategoryName("Whooper Menu");
        menuResponse1.setProductName("Whooper Burger");
        menuResponses.add(menuResponse1);

        return menuResponses;

    }

    public List<MenuResponse> getExistingCompanyNewMenuResponseList() {


        List<MenuResponse> menuResponses = new ArrayList<>();
        MenuResponse menuResponse1 = new MenuResponse();
        menuResponse1.setCount(4);
        menuResponse1.setId(0);
        menuResponse1.setIsActive(MenuState.Active);
        menuResponse1.setSize(MenuSize.Large);
        menuResponse1.setCategoryName("Whooper2 Menu");
        menuResponse1.setProductName("Whooper2 Burger");
        menuResponses.add(menuResponse1);

        return menuResponses;


    }


    private Map<String, CompanyMenuRequest> getTestDataRequest() {
        Map<String, CompanyMenuRequest> data = new HashMap<>();

        CompanyMenuRequest menu_data1 = new CompanyMenuRequest(
                new CompanyRequest(0, "McDonalds", CompanyState.Active),
                getMenuRequestList()


        );
        data.put("menu_data1", menu_data1);


        CompanyMenuRequest menu_data2 = new CompanyMenuRequest(
                new CompanyRequest(0, "KFC", CompanyState.Active),
                getSharedMenuRequestList()


        );
        data.put("menu_data2", menu_data2);

        CompanyMenuRequest menu_data3 = new CompanyMenuRequest(
                new CompanyRequest(1, "McDonalds2", CompanyState.Active),
                getExistingCompanyNewMenuRequestList()


        );
        data.put("menu_data3", menu_data3);

        return data;
    }

    private Map<String, CompanyMenuRequest> getTestDataRequestForGet() {
        Map<String, CompanyMenuRequest> data = new HashMap<>();

        CompanyMenuRequest menu_data1 = new CompanyMenuRequest(
                new CompanyRequest(0, "McDonalds", CompanyState.Active),
                getMenuRequestList()


        );
        data.put("menu_data1", menu_data1);


        CompanyMenuRequest menu_data2 = new CompanyMenuRequest(
                new CompanyRequest(0, "KFC", CompanyState.Active),
                getSharedMenuRequestList()


        );
        data.put("menu_data2", menu_data2);

        CompanyMenuRequest menu_data3 = new CompanyMenuRequest(
                new CompanyRequest(0, "McDonalds2", CompanyState.Active),
                getExistingCompanyNewMenuRequestList()


        );
        data.put("menu_data3", menu_data3);

        return data;
    }

    private Map<String, CompanyMenuResponse> getTestDataResponse() {
        Map<String, CompanyMenuResponse> data = new HashMap<>();

        CompanyMenuResponse response_data = new CompanyMenuResponse(
                new CompanyResponse(0, "McDonalds",
                        null, CompanyState.Active),
                getMenuResponseList()

        );
        data.put("menu_data1", response_data);


        CompanyMenuResponse menu_data2 = new CompanyMenuResponse(
                new CompanyResponse(0, "KFC",
                        null, CompanyState.Active),
                getSharedMenuResponseList()

        );
        data.put("menu_data2", menu_data2);

        CompanyMenuResponse menu_data3 = new CompanyMenuResponse(
                new CompanyResponse(1, "McDonalds2",
                        null, CompanyState.Active),
                getSharedMenuResponseList()

        );
        data.put("menu_data3", menu_data3);
        return data;
    }


    @Test
    public void GivenMenuSync_whenNewCompanyandMenu_thenReturnCompanyMenu() throws Exception {
        //test type Migrate new Restaurant and Menus
        CompanyMenuResponse expectedRecord = testDataresponse.get("menu_data1");
        CompanyMenuRequest requestRecord = testData.get("menu_data1");

        assertEquals(CompanyState.Active, expectedRecord.getCompanyResponse().getState());

        CompanyMenuResponse actualRecord = om.readValue(mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord)))
                .andDo(print())
                .andExpect(jsonPath("$.companyResponse.id", greaterThan(0)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);

        Assert.assertTrue(new ReflectionEquals(expectedRecord.getCompanyResponse(), new String[]{"id", "createDate"}).matches(actualRecord.getCompanyResponse()));
        Assert.assertTrue(new ReflectionEquals(expectedRecord.getMenuResponses(), new String[]{"id", "createDate"}).matches(actualRecord.getMenuResponses()));

        assertEquals(true, companyRepository.findById(actualRecord.getCompanyResponse().getId()).isPresent());
    }

    @Test
    public void GivenMenuSync_whenNewCompanyandExistingMenu_thenReturnCompanyMenu() throws Exception {
        //test type Migrate new Restaurant use sharedMenu
        // Add data
        CompanyMenuResponse expectedRecord = testDataresponse.get("menu_data1");
        CompanyMenuRequest requestRecord = testData.get("menu_data1");

        assertEquals(CompanyState.Active, expectedRecord.getCompanyResponse().getState());

        CompanyMenuResponse actualRecord = om.readValue(mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord)))
                .andDo(print())
                .andExpect(jsonPath("$.companyResponse.id", greaterThan(0)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);

        Assert.assertTrue(new ReflectionEquals(expectedRecord.getCompanyResponse(), new String[]{"id", "createDate"}).matches(actualRecord.getCompanyResponse()));
        Assert.assertTrue(new ReflectionEquals(expectedRecord.getMenuResponses(), new String[]{"id", "createDate"}).matches(actualRecord.getMenuResponses()));

        assertEquals(true, companyRepository.findById(actualRecord.getCompanyResponse().getId()).isPresent());


        //test type Migrate new Restaurant use sharedMenu
        CompanyMenuResponse expectedRecord2 = testDataresponse.get("menu_data2");
        CompanyMenuRequest requestRecord2 = testData.get("menu_data2");

        assertEquals(CompanyState.Active, expectedRecord.getCompanyResponse().getState());

        CompanyMenuResponse actualRecord2 = om.readValue(mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord2)))
                .andDo(print())
                .andExpect(jsonPath("$.companyResponse.id", greaterThan(0)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);

        Assert.assertTrue(new ReflectionEquals(expectedRecord2.getCompanyResponse(), new String[]{"id", "createDate"}).matches(actualRecord2.getCompanyResponse()));
        Assert.assertTrue(new ReflectionEquals(expectedRecord2.getMenuResponses().get(0), new String[]{"createDate"}).matches(actualRecord2.getMenuResponses().get(0)));
        Assert.assertEquals(Integer.valueOf(4), actualRecord2.getMenuResponses().get(0).getCount());

        assertEquals(true, companyRepository.findById(actualRecord2.getCompanyResponse().getId()).isPresent());


    }


    @Test
    public void GivenMenuSync_whenExistingCompanyandNewMenu_thenReturnCompanyMenu() throws Exception {
        //test type Migrate existing Restaurant new Menu
        // Add data
        CompanyMenuResponse expectedRecord = testDataresponse.get("menu_data1");
        CompanyMenuRequest requestRecord = testData.get("menu_data1");

        assertEquals(CompanyState.Active, expectedRecord.getCompanyResponse().getState());

        CompanyMenuResponse actualRecord = om.readValue(mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord)))
                .andDo(print())
                .andExpect(jsonPath("$.companyResponse.id", greaterThan(0)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);

        Assert.assertTrue(new ReflectionEquals(expectedRecord.getCompanyResponse(), new String[]{"id", "createDate"}).matches(actualRecord.getCompanyResponse()));
        Assert.assertTrue(new ReflectionEquals(expectedRecord.getMenuResponses(), new String[]{"id", "createDate"}).matches(actualRecord.getMenuResponses()));

        assertEquals(true, companyRepository.findById(actualRecord.getCompanyResponse().getId()).isPresent());


        //test type Migrate existing Restaurant new Menu
        CompanyMenuResponse expectedRecord2 = testDataresponse.get("menu_data3");
        CompanyMenuRequest requestRecord2 = testData.get("menu_data3");

        assertEquals(CompanyState.Active, expectedRecord.getCompanyResponse().getState());

        CompanyMenuResponse actualRecord2 = om.readValue(mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord2)))
                .andDo(print())
                .andExpect(jsonPath("$.companyResponse.id", greaterThan(0)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);

        Assert.assertTrue(new ReflectionEquals(expectedRecord2.getCompanyResponse(), new String[]{"createDate"}).matches(actualRecord2.getCompanyResponse()));
        Assert.assertEquals(3, actualRecord2.getMenuResponses().size());
        assertEquals(true, companyRepository.findById(actualRecord2.getCompanyResponse().getId()).isPresent());


    }

    @Test
    public void GivenMenuSync_whenNullCompanyName_thenReturnBadRequest() throws Exception {
        //test invalid CompanyName

        CompanyMenuRequest requestRecord = testData.get("menu_data1");
        requestRecord.getCompanyDto().setCompanyName("");


        mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord)))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }

    @Test
    public void GivenMenuSync_whenNullCProductName_thenReturnBadRequest() throws Exception {
        //test invalid ProductName

        CompanyMenuRequest requestRecord = testData.get("menu_data1");
        requestRecord.getMenuDto().get(0).setProductName("");


        mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord)))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }

    @Test
    public void GivenMenuSync_whenNullCCategoryName_thenReturnBadRequest() throws Exception {
        //test invalid ProductName

        CompanyMenuRequest requestRecord = testData.get("menu_data1");
        requestRecord.getMenuDto().get(0).setCategoryName("");


        mockMvc.perform(put("/syncMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(requestRecord)))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }


    @Test
    public void GivenAllCompanyParameter_whenGetOnlyCompanyList_thenReturnCompanyList() throws Exception {
        // Add data
        Map<String, CompanyMenuRequest> testData = getTestDataRequestForGet();
        Map<String, CompanyResponse> expectedMap = new HashMap<>();
        List<CompanyResponse> expected = new ArrayList<>();
        for (Map.Entry<String, CompanyMenuRequest> kv : testData.entrySet()) {
            CompanyMenuResponse response = om.readValue(mockMvc.perform(put("/syncMenu")
                            .contentType("application/json")
                            .content(om.writeValueAsString(kv.getValue())))
                    .andDo(print())
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);
            expectedMap.put(kv.getKey(), response.getCompanyResponse());
        }
        Collections.sort(Arrays.asList(expectedMap.values().toArray(new CompanyResponse[testData.size()])), Comparator.comparing(CompanyResponse::getId));


        //with companyName search /companies
        List<CompanyResponse> actualRecords = om.readValue(mockMvc.perform(get("/companies"))
                .andDo(print())
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), new TypeReference<List<CompanyResponse>>() {
        });
        expected = expectedMap.values().stream().collect(Collectors.toList());
        for (int i = 0; i < expected.size(); i++) {
            Assert.assertTrue(new ReflectionEquals(expected.get(i), new String[]{"id", "createDate"}).matches(actualRecords.get(i)));
        }
    }


    @Test
    public void GivenCompanyWithParameter_whenGetOnlyCompanyList_thenReturnCompanyList() throws Exception {
        // Add data
        Map<String, CompanyMenuRequest> testData = getTestDataRequestForGet();
        Map<String, CompanyResponse> expectedMap = new HashMap<>();
        List<CompanyResponse> expected = new ArrayList<>();
        for (Map.Entry<String, CompanyMenuRequest> kv : testData.entrySet()) {
            CompanyMenuResponse response = om.readValue(mockMvc.perform(put("/syncMenu")
                            .contentType("application/json")
                            .content(om.writeValueAsString(kv.getValue())))
                    .andDo(print())
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);
            expectedMap.put(kv.getKey(), response.getCompanyResponse());
        }
        Collections.sort(Arrays.asList(expectedMap.values().toArray(new CompanyResponse[testData.size()])), Comparator.comparing(CompanyResponse::getId));


        //with companyName search /companies?companyName=KFC
        List<CompanyResponse> actualRecords = om.readValue(mockMvc.perform(get("/companies?companyName=KFC"))
                .andDo(print())
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), new TypeReference<List<CompanyResponse>>() {
        });
        expected = expectedMap.values().stream().filter(p -> p.getCompanyName().equals("KFC")).collect(Collectors.toList());
        for (int i = 0; i < expected.size(); i++) {
            Assert.assertTrue(new ReflectionEquals(expected.get(i), new String[]{"id", "createDate"}).matches(actualRecords.get(i)));
        }
    }

    @Test
    public void GivenCompanyWithId_whenGetOnlyCompanyList_thenReturnCompanyList() throws Exception {
        // Add data
        Map<String, CompanyMenuRequest> testData = getTestDataRequestForGet();
        for (Map.Entry<String, CompanyMenuRequest> kv : testData.entrySet()) {
            CompanyMenuResponse response = om.readValue(mockMvc.perform(put("/syncMenu")
                            .contentType("application/json")
                            .content(om.writeValueAsString(kv.getValue())))
                    .andDo(print())
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);
        }


        //with companyName search /companies?id=1
        List<CompanyResponse> actualRecords = om.readValue(mockMvc.perform(get("/companies?id=1"))
                .andDo(print())
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), new TypeReference<List<CompanyResponse>>() {
        });
        Assert.assertEquals(Integer.valueOf(1), actualRecords.get(0).getId());
    }

    @Test
    public void GivenMenuWithId_whenOfferMenu_thenReturnResultOfOffer() throws Exception {
        // Add data
        Map<String, CompanyMenuRequest> testData = getTestDataRequestForGet();
        for (Map.Entry<String, CompanyMenuRequest> kv : testData.entrySet()) {
            CompanyMenuResponse response = om.readValue(mockMvc.perform(put("/syncMenu")
                            .contentType("application/json")
                            .content(om.writeValueAsString(kv.getValue())))
                    .andDo(print())
                    .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), CompanyMenuResponse.class);
        }

    // offer id =1 Menu
        OfferMenuResponse response = om.readValue(mockMvc.perform(put("/offerMenu")
                        .contentType("application/json")
                        .content(om.writeValueAsString(1)))
                .andDo(print())
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), OfferMenuResponse.class);
        Assert.assertTrue(response.getIsOffered());
    }


}
